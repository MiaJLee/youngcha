(function(){"use strict";const f={flight:{icon:"🛩",name:"유럽 왕복 일등석 항공권",price:12e6,id:"flight"},tesla:{icon:"🏎",name:"테슬라 Model 3",price:4199e4,id:"tesla"},custom:null};function m(){return f.custom?f.custom:f.tesla}const t={isVisible:!1,widget:null,currentPrice:0,userData:{rsuAmount:135,avgPrice:37150},settings:{enableWidget:!0,theme:"light",enableNotifications:!0},notifiedTargets:{},isMinimized:!1,widgetPosition:null};function D(){const{currentPrice:e,userData:i}=t,{rsuAmount:o=135,avgPrice:r=37150}=i,n=o*e;let s=0,d="#333333";r>0&&e>0&&(s=(e-r)/r*100,d=s>=0?"#28a745":"#dc3545");const a=m().price,c=Math.min(n/a*100,100);return`
        <div id="rsu-tracker-widget" style="
            position: fixed;
            bottom: 20px;
            right: 20px;
            width: 250px;
            background: rgba(255,255,255,0.4);
            border: 1px solid rgba(233,236,239,0.5);
            border-radius: 12px;
            box-shadow: 0 8px 32px 0 rgba(31,38,135,0.18);
            backdrop-filter: blur(12px);
            -webkit-backdrop-filter: blur(12px);
            font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
            z-index: 999999;
            color: #333333;
            transition: all 0.3s ease;
        ">
            <div id="widget-header" style="
                padding: 12px 16px;
                border-bottom: 1px solid rgba(233,236,239,0.5);
                border-radius: 12px 12px 0 0;
                cursor: move;
                display: flex;
                justify-content: space-between;
                align-items: center;
            ">
                <div style="font-weight: 600; font-size: 14px; color: #333333;">🐜 영차영차 카카오</div>
                <div style="display: flex; gap: 6px;">
                    <button id="widget-minimize" style="
                        background: none;
                        border: 1px solid rgba(233,236,239,0.5);
                        color: #495057;
                        width: 24px;
                        height: 24px;
                        border-radius: 4px;
                        cursor: pointer;
                        font-size: 12px;
                        display: flex;
                        align-items: center;
                        justify-content: center;
                        transition: all 0.3s ease;
                    " title="최소화">−</button>
                    <button id="widget-close" style="
                        background: none;
                        border: 1px solid rgba(233,236,239,0.5);
                        color: #495057;
                        width: 24px;
                        height: 24px;
                        border-radius: 4px;
                        cursor: pointer;
                        font-size: 12px;
                        display: flex;
                        align-items: center;
                        justify-content: center;
                        transition: all 0.3s ease;
                    " title="닫기">×</button>
                </div>
            </div>
            <div id="widget-content" style="padding: 16px;">
                <div style="display: flex; justify-content: space-between; margin-bottom: 12px;">
                    <span style="color: #495057; font-size: 12px;">현재가</span>
                    <span id="widget-price" style="font-weight: 600; color: #333333;">₩${e.toLocaleString()}</span>
                </div>
                <div style="display: flex; justify-content: space-between; margin-bottom: 12px;">
                    <span style="color: #495057; font-size: 12px;">나의 RSU</span>
                    <span id="widget-asset" style="font-weight: 600; color: #28a745;">₩${n.toLocaleString()}</span>
                </div>
                <div style="display: flex; justify-content: space-between; margin-bottom: 16px;">
                    <span style="color: #495057; font-size: 12px;">수익률</span>
                    <span id="widget-profit" style="font-weight: 600; color: ${d};">${s>0?"+":""}${s.toFixed(1)}%</span>
                </div>
                <div id="widget-progress-section" style="margin-top: 12px; padding-top: 12px; border-top: 1px solid rgba(233,236,239,0.5);">
                    <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 8px;">
                        <span id="widget-target-label" style="color: #495057; font-size: 12px;">🎯 목표까지</span>
                        <span id="widget-target-percent" style="font-size: 12px; font-weight: 600; color: #007bff;">${c.toFixed(1)}%</span>
                    </div>
                    <div id="widget-progress-container" style="
                        background: #e9ecef; 
                        height: 8px; 
                        border-radius: 4px; 
                        overflow: hidden;
                        position: relative;
                    ">
                        <div id="widget-target-progress" style="
                            height: 100%;
                            background: #007bff;
                            width: ${c}%;
                            transition: width 0.5s ease;
                            border-radius: 4px;
                        "></div>
                    </div>
                </div>
            </div>
            <div id="widget-minimized" style="
                display: none;
                padding: 8px 16px;
                background: #f8f9fa;
                border-radius: 12px;
                height: 30px;
                align-items: center;
                justify-content: space-between;
            ">
                <div style="display: flex; align-items: center; gap: 8px; flex: 1;">
                    <div id="widget-target-emoji-mini" style="
                        font-size: 16px;
                        line-height: 1;
                        flex-shrink: 0;
                    ">🎯</div>
                    <div id="widget-progress-container-mini" style="
                        background: #e9ecef; 
                        height: 6px; 
                        border-radius: 3px; 
                        overflow: hidden;
                        position: relative;
                        flex: 1;
                        min-width: 100px;
                    ">
                        <div id="widget-target-progress-mini" style="
                            height: 100%;
                            background: #007bff;
                            width: ${c}%;
                            transition: width 0.5s ease;
                            border-radius: 3px;
                        "></div>
                    </div>
                    <span id="widget-target-percent-mini" style="
                        font-size: 11px; 
                        font-weight: 600; 
                        color: #007bff;
                        min-width: 35px;
                        flex-shrink: 0;
                    ">${c.toFixed(1)}%</span>
                </div>
                <button id="widget-maximize" style="
                    background: none;
                    border: none;
                    color: #495057;
                    width: 20px;
                    height: 20px;
                    cursor: pointer;
                    font-size: 10px;
                    display: flex;
                    align-items: center;
                    justify-content: center;
                    margin-left: 8px;
                " title="최대화">+</button>
            </div>
        </div>
    `}function w(){const e=document.getElementById("rsu-tracker-widget");e&&e.remove(),document.body.insertAdjacentHTML("beforeend",D()),t.widget=document.getElementById("rsu-tracker-widget"),t.widget&&(t.widget.setAttribute("data-widget-protected","true"),new MutationObserver(o=>{o.forEach(r=>{r.removedNodes.forEach(n=>{(n===t.widget||n.nodeType===Node.ELEMENT_NODE&&n.querySelector&&n.querySelector("#rsu-tracker-widget"))&&t.settings.enableWidget!==!1&&setTimeout(()=>{document.getElementById("rsu-tracker-widget")||w()},50)})})}).observe(document.body,{childList:!0,subtree:!0})),chrome.storage.sync.get(["widgetPosition"],i=>{i.widgetPosition&&t.widget&&(t.widget.style.left=i.widgetPosition.left,t.widget.style.top=i.widgetPosition.top,t.widget.style.right="auto",t.widget.style.bottom="auto")}),T(),u(),chrome.storage.sync.get(["widgetMinimized"],i=>{i.widgetMinimized?h():v()})}function T(){const e=t.widget;if(!e)return;const i=e.querySelector("#widget-close");i&&i.addEventListener("click",()=>{p(),chrome.storage.sync.get(["settings"],g=>{const a=g.settings||{};a.enableWidget=!1,chrome.storage.sync.set({settings:a})})});const o=e.querySelector("#widget-minimize"),r=e.querySelector("#widget-maximize"),n=e.querySelector("#widget-content"),s=e.querySelector("#widget-minimized"),d=e.querySelector("#widget-header");o&&n&&s&&d&&o.addEventListener("click",()=>{h()}),r&&n&&s&&d&&r.addEventListener("click",()=>{v()}),P()}function P(){const e=t.widget,i=e.querySelector("#widget-header"),o=e.querySelector("#widget-minimized");let r=!1;const n={x:0,y:0};i&&i.addEventListener("mousedown",s=>{if(s.target.tagName==="BUTTON")return;r=!0;const d=e.getBoundingClientRect();n.x=s.clientX-d.left,n.y=s.clientY-d.top,s.preventDefault()}),o&&o.addEventListener("mousedown",s=>{if(s.target.tagName==="BUTTON")return;r=!0;const d=e.getBoundingClientRect();n.x=s.clientX-d.left,n.y=s.clientY-d.top,s.preventDefault()}),document.addEventListener("mousemove",s=>{if(!r)return;const d=s.clientX-n.x,g=s.clientY-n.y,a=window.innerWidth-e.offsetWidth,c=window.innerHeight-e.offsetHeight;e.style.left=Math.max(0,Math.min(d,a))+"px",e.style.top=Math.max(0,Math.min(g,c))+"px",e.style.right="auto",e.style.bottom="auto"}),document.addEventListener("mouseup",()=>{r&&e&&chrome.storage.sync.set({widgetPosition:{left:e.style.left,top:e.style.top}}),r=!1})}function y(){const e=t.widget;if(!e)return;const{currentPrice:i,userData:o}=t,{rsuAmount:r=0}=o,n=r*i,s=m(),d=s.price,g=Math.min(n/d*100,100),a=e.querySelector("#widget-target-label");if(a){const j=s.icon||"🎯",A=s.name||"목표";a.textContent=`${j} ${A}까지`}const c=e.querySelector("#widget-target-progress"),S=e.querySelector("#widget-target-percent");c&&(c.style.width=`${g}%`),S&&(S.textContent=`${g.toFixed(1)}%`);const z=e.querySelector("#widget-target-progress-mini"),W=e.querySelector("#widget-target-percent-mini"),k=e.querySelector("#widget-target-emoji-mini");z&&(z.style.width=`${g}%`),W&&(W.textContent=`${g.toFixed(1)}%`),k&&(k.textContent=s.icon||"🎯")}function u(){const e=t.widget;if(!e||!t.isVisible)return;const{currentPrice:i,userData:o}=t,{rsuAmount:r=0,avgPrice:n=0}=o,s=e.querySelector("#widget-price");s&&(s.textContent=`₩${i.toLocaleString()}`,s.style.color="#333333");const d=r*i,g=e.querySelector("#widget-asset");g&&(g.textContent=`₩${d.toLocaleString()}`);const a=e.querySelector("#widget-profit");if(a&&n>0){const c=(i-n)/n*100;a.textContent=`${c>0?"+":""}${c.toFixed(1)}%`,a.style.color=c>=0?"#28a745":"#dc3545"}y(),$()}function l(){t.widget||w(),t.widget&&(t.widget.style.display="block",t.isVisible=!0,u())}function p(){t.widget&&(t.widget.style.display="none",t.isVisible=!1)}function E(){t.widget&&(t.widget.remove(),t.widget=null,t.isVisible=!1)}function M(e){e.price!==void 0&&(t.currentPrice=e.price),e.userData&&(t.userData={...t.userData,...e.userData}),e.settings&&(t.settings={...t.settings,...e.settings}),u()}chrome.runtime.onMessage.addListener((e,i,o)=>{switch(e.action){case"updateWidget":M(e),!t.widget&&t.settings.enableWidget!==!1&&l();break;case"showWidget":l();break;case"hideWidget":p();break;case"removeWidget":E();break}}),chrome.storage.onChanged.addListener((e,i)=>{if(i==="sync"||i==="local"){if(e.settings){const o=e.settings.newValue||{};t.settings={...t.settings,...o},o.enableWidget===!1?p():o.enableWidget===!0&&l()}if(e.userData&&(t.userData={...t.userData,...e.userData.newValue},u()),e.customTarget&&(f.custom=e.customTarget.newValue,u()),e.priceData){const o=e.priceData.newValue||{};o.currentPrice&&(t.currentPrice=o.currentPrice,u())}}});async function b(){try{const e=await chrome.storage.sync.get(["settings","userData","priceData"]),i=await chrome.storage.local.get(["customTarget","lastPrice"]);t.settings=e.settings||{enableWidget:!0},t.userData={rsuAmount:135,avgPrice:37150,...e.userData},i.customTarget&&(f.custom=i.customTarget),e.priceData.currentPrice&&(t.currentPrice=e.priceData.currentPrice),t.settings.enableWidget!==!1&&(u(),l())}catch(e){console.error("위젯 초기화 실패:",e),t.settings.enableWidget!==!1&&l()}}document.readyState==="loading"?document.addEventListener("DOMContentLoaded",b):b(),document.addEventListener("visibilitychange",()=>{document.visibilityState==="visible"&&(t.settings.enableWidget!==!1&&!t.widget&&l(),t.widget&&t.isVisible&&(t.widget.style.display="block"))}),window.addEventListener("focus",()=>{t.settings.enableWidget!==!1&&!t.widget&&l()});let x=window.location.href;new MutationObserver(()=>{window.location.href!==x&&(x=window.location.href,t.settings.enableWidget!==!1&&!t.widget&&setTimeout(()=>{l()},100))}).observe(document.body,{childList:!0,subtree:!0}),window.addEventListener("popstate",()=>{setTimeout(()=>{t.settings.enableWidget!==!1&&!t.widget&&l()},100)});const q=history.pushState,L=history.replaceState;history.pushState=function(...e){q.apply(history,e),setTimeout(()=>{t.settings.enableWidget!==!1&&!t.widget&&l()},100)},history.replaceState=function(...e){L.apply(history,e),setTimeout(()=>{t.settings.enableWidget!==!1&&!t.widget&&l()},100)},setInterval(()=>{document.visibilityState==="visible"&&t.settings.enableWidget!==!1&&(t.widget?t.isVisible&&t.widget.style.display==="none"&&(t.widget.style.display="block"):l())},3e4);function $(){if(!t.settings.enableNotifications)return;const{currentPrice:e,userData:i}=t,{rsuAmount:o=0}=i,r=o*e;Object.values(f).forEach(n=>{if(!n||!n.price||!n.name)return;const s=r/n.price*100;s>=100&&!t.notifiedTargets[n.id]&&(chrome.runtime.sendMessage({action:"notifyTargetAchieved",target:{id:n.id,name:n.name,icon:n.icon}}),t.notifiedTargets[n.id]=!0),s<100&&(t.notifiedTargets[n.id]=!1)})}function h(){const e=t.widget;if(!e)return;const i=e.querySelector("#widget-content"),o=e.querySelector("#widget-minimized"),r=e.querySelector("#widget-header");i&&o&&r&&(i.style.display="none",r.style.display="none",o.style.display="flex",e.style.height="30px",t.isMinimized=!0,chrome.storage.sync.set({widgetMinimized:!0}),y())}function v(){const e=t.widget;if(!e)return;const i=e.querySelector("#widget-content"),o=e.querySelector("#widget-minimized"),r=e.querySelector("#widget-header");i&&o&&r&&(i.style.display="block",r.style.display="flex",o.style.display="none",e.style.height="auto",t.isMinimized=!1,chrome.storage.sync.set({widgetMinimized:!1}))}})();
